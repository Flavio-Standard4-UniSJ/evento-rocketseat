const express = require("express")
const server = express()
server.use(express.static("public"))

const nunjucks = require("nunjucks")
nunjucks.configure("src/views", {
    express: server,
    noCache: true
})

server.get("/",(req, res)=>{
    return res.render("index.html")
})

server.get("/novo-contato",(req, res)=>{
    return res.render("novo-contato.html")
})

server.get("/contatos",(req, res)=>{
    return res.render("contatos.html")
})

//.get("/novo-contato", pages.novo-contato)

//.post("/salvarContato", pages.salvarContato)

server.listen(5500)

